import math

s = round(math.pi, 4)*10

print(s)